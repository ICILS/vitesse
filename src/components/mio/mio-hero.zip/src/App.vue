
<template>
  <MioHero  />
</template>

<script>
import MioHero from "./MioHero.vue";
export default {
  name: "App",
  components: {
    MioHero: MioHero,
  },
};
</script>

<style>
</style>

